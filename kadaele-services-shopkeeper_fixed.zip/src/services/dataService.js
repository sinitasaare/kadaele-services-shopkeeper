import localforage from 'localforage';
import { auth, db } from './firebaseConfig';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  addDoc,
  serverTimestamp,
  limit
} from 'firebase/firestore';

// Configure LocalForage
localforage.config({
  name: 'KadaeleServices',
  storeName: 'shopkeeper_data'
});

class DataService {
  constructor() {
    this.currentUser = null;
    this.syncQueue = [];
    
    // Listen for auth state changes
    auth.onAuthStateChanged((user) => {
      this.currentUser = user;
      if (user) {
        console.log('User logged in:', user.email);
        // Start background sync when user logs in
        this.startBackgroundSync();
      }
    });

    // Check online status periodically
    this.isOnline = navigator.onLine;
    window.addEventListener('online', () => {
      this.isOnline = true;
      console.log('🌐 Back online - syncing...');
      this.syncToCloud();
    });
    window.addEventListener('offline', () => {
      this.isOnline = false;
      console.log('📴 Offline mode');
    });
  }

  // ==================== LOCAL STORAGE (PRIMARY) ====================

  async saveLocal(key, data) {
    try {
      await localforage.setItem(key, data);
      console.log(`💾 Saved ${key} locally`);
      return true;
    } catch (error) {
      console.error(`Error saving ${key}:`, error);
      return false;
    }
  }

  async getLocal(key) {
    try {
      const data = await localforage.getItem(key);
      return data || [];
    } catch (error) {
      console.error(`Error reading ${key}:`, error);
      return [];
    }
  }

  async addToQueue(action, data) {
    const queue = await this.getLocal('sync_queue') || [];
    queue.push({ action, data, timestamp: Date.now() });
    await this.saveLocal('sync_queue', queue);
    console.log(`📋 Queued: ${action}`);
  }

  // ==================== GOODS (INVENTORY) ====================

  async getGoods() {
    // 1. Get from local storage (fast)
    const localGoods = await this.getLocal('goods');
    
    // 2. Try to sync from cloud in background
    this.syncGoodsFromCloud();
    
    return localGoods;
  }

  async syncGoodsFromCloud() {
    if (!this.isOnline()) return;
    
    try {
      const goodsRef = collection(db, 'goods');
      const snapshot = await getDocs(goodsRef);
      const goods = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      await this.saveLocal('goods', goods);
      console.log(`✅ Synced ${goods.length} products from cloud`);
    } catch (error) {
      console.log('⚠️ Cloud sync failed, using local data');
    }
  }

  // ==================== PURCHASES (SALES) ====================

  async addPurchase(purchase) {
    // 1. Generate local ID
    const localId = `purchase_${Date.now()}`;
    purchase.id = localId;
    purchase.createdAt = new Date();
    purchase.synced = false;

    // 2. Save to local storage FIRST
    const purchases = await this.getLocal('purchases') || [];
    purchases.unshift(purchase);
    await this.saveLocal('purchases', purchases);
    console.log('💾 Purchase saved locally');

    // 3. Queue for cloud sync
    await this.addToQueue('addPurchase', purchase);

    // 4. Try immediate sync if online
    if (this.isOnline) {
      this.syncToCloud();
    }

    return purchase;
  }

  async getPurchases() {
    // Always return local data (fast!)
    const purchases = await this.getLocal('purchases') || [];
    
    // Sync in background
    this.syncPurchasesFromCloud();
    
    return purchases;
  }

  async syncPurchasesFromCloud() {
    if (!this.isOnline) return;
    
    try {
      const purchasesRef = collection(db, 'purchases');
      const q = query(purchasesRef, orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const cloudPurchases = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        synced: true
      }));
      
      // Merge with local (keep unsynced local purchases)
      const localPurchases = await this.getLocal('purchases') || [];
      // Merge by id, preferring cloud when ids match.
      // This prevents local purchases from being wiped when cloud returns empty.
      const mergedMap = new Map();
      for (const p of localPurchases) {
        if (!p) continue;
        mergedMap.set(p.id, p);
      }
      for (const p of cloudPurchases) {
        if (!p) continue;
        mergedMap.set(p.id, p);
      }

      const merged = Array.from(mergedMap.values());
      merged.sort((a, b) => {
        const at = new Date(a.timestamp || a.createdAt || 0).getTime();
        const bt = new Date(b.timestamp || b.createdAt || 0).getTime();
        return bt - at;
      });

      await this.saveLocal('purchases', merged);
      console.log('✅ Purchases synced');
    } catch (error) {
      console.log('⚠️ Using local purchases only');
    }
  }

  // ==================== DEBTORS ====================

  async getDebtors() {
    const debtors = await this.getLocal('debtors') || [];
    
    // Sync in background
    this.syncDebtorsFromCloud();
    
    return debtors;
  }

  async syncDebtorsFromCloud() {
    if (!this.isOnline) return;
    
    try {
      const debtorsRef = collection(db, 'debtors');
      const snapshot = await getDocs(debtorsRef);
      const debtors = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      await this.saveLocal('debtors', debtors);
      console.log('✅ Debtors synced');
    } catch (error) {
      console.log('⚠️ Using local debtors only');
    }
  }

  async updateDebtor(purchase) {
    if (!purchase.isDebt) return;

    // Update local debtors
    const debtors = await this.getLocal('debtors') || [];
    const existingIndex = debtors.findIndex(d => 
      d.phone === purchase.customerPhone && d.name === purchase.customerName
    );

    if (existingIndex >= 0) {
      // Update existing
      debtors[existingIndex].totalDebt += purchase.total;
      debtors[existingIndex].purchaseIds.push(purchase.id);
    } else {
      // Create new
      debtors.push({
        id: `debtor_${Date.now()}`,
        name: purchase.customerName,
        phone: purchase.customerPhone,
        totalDebt: purchase.total,
        purchaseIds: [purchase.id],
        repaymentDate: purchase.repaymentDate,
        createdAt: new Date()
      });
    }

    await this.saveLocal('debtors', debtors);
    
    // Queue for sync
    await this.addToQueue('updateDebtor', purchase);
  }

  // ==================== CLOUD SYNC ====================

  async syncToCloud() {
    const queue = await this.getLocal('sync_queue') || [];
    if (queue.length === 0) return;

    console.log(`🔄 Syncing ${queue.length} items to cloud...`);

    for (let i = 0; i < queue.length; i++) {
      const item = queue[i];
      
      try {
        if (item.action === 'addPurchase') {
          await this.syncPurchaseToCloud(item.data);
        } else if (item.action === 'updateDebtor') {
          await this.syncDebtorToCloud(item.data);
        }
        
        // Remove from queue after successful sync
        queue.splice(i, 1);
        i--;
      } catch (error) {
        console.error('Sync failed for item:', error);
      }
    }

    // Save updated queue
    await this.saveLocal('sync_queue', queue);
    console.log('✅ Cloud sync complete');
  }

  async syncPurchaseToCloud(purchase) {
    // Use the same id locally and in Firestore.
    // Replacing local ids with Firestore auto-ids can break merges and make
    // records appear to vanish after navigation.
    const purchaseId = purchase?.id || `${Date.now()}`;
    const purchaseDoc = doc(db, 'purchases', purchaseId);

    await setDoc(
      purchaseDoc,
      {
        ...purchase,
        id: purchaseId,
        createdAt: serverTimestamp(),
        isVoided: false,
        isRefunded: false,
        synced: true,
      },
      { merge: true }
    );

    // Mark local purchase as synced (keep the same id)
    const purchases = (await this.getLocal('purchases')) || [];
    const index = purchases.findIndex(p => p.id === purchaseId);
    if (index >= 0) {
      purchases[index].synced = true;
      await this.saveLocal('purchases', purchases);
    }

    // Sync debtor if needed
    if (purchase.isDebt) {
      await this.syncDebtorToCloud(purchase);
    }
  }

  async syncDebtorToCloud(purchase) {
    const debtorsRef = collection(db, 'debtors');
    const q = query(
      debtorsRef,
      where('phone', '==', purchase.customerPhone || ''),
      where('name', '==', purchase.customerName || '')
    );
    const snapshot = await getDocs(q);

    if (!snapshot.empty) {
      // Update existing
      const debtorDoc = snapshot.docs[0];
      const currentData = debtorDoc.data();
      await updateDoc(doc(db, 'debtors', debtorDoc.id), {
        purchaseIds: [...(currentData.purchaseIds || []), purchase.id],
        totalDebt: (currentData.totalDebt || 0) + purchase.total,
        repaymentDate: purchase.repaymentDate || currentData.repaymentDate,
        lastPurchaseDate: serverTimestamp()
      });
    } else {
      // Create new
      await addDoc(debtorsRef, {
        name: purchase.customerName,
        phone: purchase.customerPhone,
        purchaseIds: [purchase.id],
        totalDebt: purchase.total,
        totalPaid: 0,
        repaymentDate: purchase.repaymentDate || '',
        createdAt: serverTimestamp()
      });
    }
  }

  async startBackgroundSync() {
    // Sync every 5 minutes if online
    setInterval(() => {
      if (this.isOnline) {
        this.syncToCloud();
      }
    }, 5 * 60 * 1000);
  }

  // ==================== AUTH ====================

  async login(email, password) {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      return { success: true, user: userCredential.user };
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, error: error.message };
    }
  }

  async logout() {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  }

  // ==================== OTHER METHODS (keep existing) ====================
  
  async savePhoto(photoBase64, filename) {
    // For offline-first, just return the base64 data
    // In the future, could upload to Firebase Storage when online
    return photoBase64;
  }

  async recordPayment(debtorId, amount) {
    // Update local debtor
    const debtors = await this.getLocal('debtors') || [];
    const debtorIndex = debtors.findIndex(d => d.id === debtorId);
    
    if (debtorIndex >= 0) {
      debtors[debtorIndex].totalDebt -= amount;
      debtors[debtorIndex].totalPaid = (debtors[debtorIndex].totalPaid || 0) + amount;
      await this.saveLocal('debtors', debtors);
      
      // Queue for cloud sync
      await this.addToQueue('recordPayment', { debtorId, amount });
      
      // Try immediate sync
      if (this.isOnline) {
        this.syncPaymentToCloud(debtorId, amount);
      }
    }
  }

  async syncPaymentToCloud(debtorId, amount) {
    try {
      const debtorRef = doc(db, 'debtors', debtorId);
      const debtorDoc = await getDoc(debtorRef);
      
      if (debtorDoc.exists()) {
        const debtor = debtorDoc.data();
        await updateDoc(debtorRef, {
          totalDebt: (debtor.totalDebt || 0) - amount,
          totalPaid: (debtor.totalPaid || 0) + amount
        });
      }
    } catch (error) {
      console.error('Payment sync failed:', error);
    }
  }

    getCurrentUser() {
    return this.currentUser;
  }

  async sendPasswordReset(email) {
    // Firebase password reset
    const { sendPasswordResetEmail } = await import('firebase/auth');
    try {
      await sendPasswordResetEmail(auth, email);
      return true;
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  }

  async getLastSyncTime() {
    // Return last sync timestamp from local storage
    const syncTime = await this.getLocal('last_sync_time');
    return syncTime || null;
  }

  async syncToServer() {
    // Alias for syncToCloud
    return await this.syncToCloud();
  }

    getCurrentUser() {
    return this.currentUser;
  }

  async sendPasswordReset(email) {
    // Firebase password reset
    const { sendPasswordResetEmail } = await import('firebase/auth');
    try {
      await sendPasswordResetEmail(auth, email);
      return true;
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  }

  async getLastSyncTime() {
    // Return last sync timestamp from local storage
    const syncTime = await this.getLocal('last_sync_time');
    return syncTime || null;
  }

  async syncToServer() {
    // Alias for syncToCloud
    return await this.syncToCloud();
  }

    generateId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}

export default new DataService();
